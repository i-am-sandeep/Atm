package com.amodcs.atm.niteenkumar;

import java.util.*;


public class Main {
    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
                
                
                System.out.println("[********************Welcome********************]");
                System.out.println();
                System.out.println("[****************Enter your PIN-****************]");
                String pin_in=sc.next();
                 
                boolean verifyPin=DatabaseFunction.verifyPin(pin_in);
                if(verifyPin){
                    boolean flag=true;
                    while(flag){
                        System.out.println();
                        System.out.println("[****************Enter your Choice-****************]");
                        System.out.println("1. Check your balance");
                        System.out.println("2. Withdrawl");
                        System.out.println("3. Transfer");
                        System.out.println("4. Payment History");
                        System.out.println("5. Reset PIN");
                        System.out.println("6. Exit");
                        int ch=sc.nextInt();
                        switch(ch){
                            case 1:
                                    System.out.println("Balance: "+DatabaseFunction.getBalance(pin_in));
                            break;
                            case 2: Withdrawl.doWithdrawl(pin_in);
                            break;
                            case 3: Transfer.doTransfer(pin_in);
                            break;
                            case 4: System.out.println("Enter your account number: ");
                                    String account=sc.next();
                                    PaymentHistory.display(account);
                            break;
                            case 5: System.out.println("Enter new PIN: ");
                                    String newPin=sc.next();
                                    if(DatabaseFunction.setPin(pin_in,newPin)){
                                        System.out.println("PIN is reset.");
                                    }else{
                                        System.out.println("Error.");
                                    }
                            break;
                            default: flag=false;
                        }
                    }
                }else{
                    System.out.println("PIN is incorrect.");
                }
     
            } catch (ClassNotFoundException e) {
                
                e.printStackTrace();
            }
            System.out.println("Thank You.");
            
        sc.close();
    }
}