package com.amodcs.atm.niteenkumar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Transfer {
    public static void doTransfer(String pin){
        
        
        try {
            String query="Select * from atm_users_details where pin=?";
            Connection connection = DatabaseConnection.getConnection();
        
        PreparedStatement statement=connection.prepareStatement(query);
        statement.setString(1,pin);
        
        ResultSet resultSet=statement.executeQuery();

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your account number: ");
        String srcAccount=sc.next();
        System.out.println("Enter recipient account number: ");
        String recipAccount=sc.next();
        System.out.println("Enter the amount: ");
        double transferAmount=sc.nextDouble();

        String account="";
        if(resultSet.next()){
            account = resultSet.getString("accountNumber");
        if(srcAccount.equals(account)){
            boolean status=DatabaseFunction.transferMoney(srcAccount,recipAccount,transferAmount);
            if(status){
                System.out.println("Amount is transfered to recipient account.");
            }else{
                System.out.println("Error.");
            }
        }else{
            System.out.println("Invalid Source account credentials");
        }
    }
        
    }
    catch (SQLException e) {
            
            e.printStackTrace();
        }
    }
}
