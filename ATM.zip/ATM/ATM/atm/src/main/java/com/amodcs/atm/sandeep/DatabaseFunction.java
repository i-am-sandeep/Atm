package com.amodcs.atm.niteenkumar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseFunction {
    
    //pin verification
    public static boolean verifyPin(String pin){
        String query="Select * from atm_users_details where pin=?";

        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1,pin);

            ResultSet resultSet=statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean setPin(String oldPin,String newPin){
        String query="Select * from atm_users_details where pin=?";

        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1,oldPin);

            //ResultSet resultSet=statement.executeQuery();
            String updateQuery="Update atm_users_details Set pin=? where pin=?";
            PreparedStatement updateStatement=connection.prepareStatement(updateQuery);
            updateStatement.setString(1,newPin);
            updateStatement.setString(2,oldPin);

            int row=updateStatement.executeUpdate();
            if(row>0){
                return true;
            }else{
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //balance
    public static double getBalance(String pin){
        String query="Select * from atm_users_details where pin=?";
        try {
            double currBalance=0.0;
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1,pin);

            ResultSet resultSet=statement.executeQuery();
            if(resultSet.next()){
                currBalance=resultSet.getDouble("balance");
            }
            
            return currBalance;
        } catch (SQLException e) {
            
            e.printStackTrace();
            return 0.0;
        }
        
    }

    //withdraw
    public static boolean withdrawlAmount(String pin,double amount){
        String query="Select * from atm_users_details where pin=?";

        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1,pin);

            ResultSet resultSet=statement.executeQuery();
            if(resultSet.next()){
                double currntBalance=resultSet.getDouble("balance");
                
                if(currntBalance>=amount){
                    double newBalance=currntBalance-amount;
                    String updateQuery="Update atm_users_details Set balance=? where pin=?";
                    PreparedStatement updateStatement=connection.prepareStatement(updateQuery); 
                    updateStatement.setDouble(1, newBalance);
                    updateStatement.setString(2, pin);

                    int row=updateStatement.executeUpdate();
                    if(row>0){
                        String account=resultSet.getString("accountNumber");
                        PaymentHistory.withdrawlHistory(account,amount,newBalance);
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }else{
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //tranfer money into another account
    public static boolean transferMoney(String sourceNumber,String recipientNumber,double amount){
        String  query1="Select * from atm_users_details where accountNumber=?";
        String src="Update atm_users_details Set balance=balance-? where accountNumber=?";
        String dest="Update atm_users_details Set balance=balance+? where accountNumber=?";

        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement srcStatement=connection.prepareStatement(src);
            PreparedStatement destStatement=connection.prepareStatement(dest);
            connection.setAutoCommit(false);

            srcStatement.setDouble(1, amount);
            srcStatement.setString(2, sourceNumber);
            int srcAffect=srcStatement.executeUpdate();

            destStatement.setDouble(1, amount);
            destStatement.setString(2, recipientNumber);
            int destAffect=destStatement.executeUpdate();
            if(srcAffect>0 && destAffect>0){
                connection.commit();

                PreparedStatement srcST=connection.prepareStatement(query1);
                PreparedStatement destST=connection.prepareStatement(query1);

                srcST.setString(1, sourceNumber);
                ResultSet srcRS=srcST.executeQuery();
                if(srcRS.next()){
                    double srcBal=srcRS.getDouble("balance");
                    PaymentHistory.transferHistory(sourceNumber,0.0,amount,srcBal);
                }

                destST.setString(1, recipientNumber);
                ResultSet destRS=destST.executeQuery();
                if(destRS.next()){
                    double destBal=destRS.getDouble("balance");
                    PaymentHistory.transferHistory(recipientNumber,amount,0.0,destBal);
                }

                return true;
            }else{
                connection.rollback();
                return false;
            }

        } catch (SQLException e) {
            
            e.printStackTrace();
            return false;
        }
        
    }
}
