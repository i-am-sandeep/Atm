package com.amodcs.atm.niteenkumar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;


public class PaymentHistory {

    public static void display(String account){
        String query="Select * from payment_history where accountNumber=?";
        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1,account);

            ResultSet resultSet=statement.executeQuery();
            System.out.println("-------------------------History-------------------------");
            System.out.println();
            System.out.println("Account Number\tCredit\tDebit\tBalance\tTime");
            while(resultSet.next()){
                String number=resultSet.getString("accountNumber");
                double credit=resultSet.getDouble("credit");
                double debit=resultSet.getDouble("debit");
                double balance=resultSet.getDouble("balance");
                Timestamp time=resultSet.getTimestamp("time");
                
                System.out.println(number+"\t\t"+credit+"\t"+debit+"\t"+balance+"\t"+time);
                System.out.println();
                System.out.println();
            }
        } catch (SQLException e) {
            
            e.printStackTrace();
        }
    }

    public static void withdrawlHistory(String account,double amount,double balance){
        recordTransaction(account,0.0,amount,balance);
    }

    public static void transferHistory(String account,double credit,double debit,double balance){
        recordTransaction(account, credit, debit, balance);
    }

    private static void recordTransaction(String account,double credit,double debit,double balance){
        String query="Insert into payment_history (accountNumber,credit,debit,balance,time) Values (?,?,?,?,?)";

        try {
            Connection connection=DatabaseConnection.getConnection();
            PreparedStatement statement=connection.prepareStatement(query);
            statement.setString(1, account);
            statement.setDouble(2, credit);
            statement.setDouble(3, debit);
            statement.setDouble(4, balance);
            statement.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));

            statement.executeUpdate();

        } catch (SQLException e) {
            
            e.printStackTrace();
        }
    }
}
