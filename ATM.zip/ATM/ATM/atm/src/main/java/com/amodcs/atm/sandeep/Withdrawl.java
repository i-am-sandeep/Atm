package com.amodcs.atm.niteenkumar;

import java.util.Scanner;

public class Withdrawl {
    public static void doWithdrawl(String pin){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the amount: ");
        double withdrawlAmount=sc.nextDouble();
        if(DatabaseFunction.withdrawlAmount(pin,withdrawlAmount)){
            System.out.println("Amount Deducted. Collect your money.");
            System.out.println("Balance: "+DatabaseFunction.getBalance(pin));
        }else{
            System.out.println("Insufficient money.");
        }
    }
}
